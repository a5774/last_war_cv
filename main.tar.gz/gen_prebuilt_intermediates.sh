#!/bin/bash
python3 gen_table_fourcc.py include/drm/drm_fourcc.h generated_static_table_fourcc.h
